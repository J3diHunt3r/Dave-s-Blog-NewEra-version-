Simple Blog part 1: The Build
=============

These files acompany the tutorial: [Creating a blog from scratch with PHP](https://daveismyname.blog/creating-a-blog-from-scratch-with-php)
